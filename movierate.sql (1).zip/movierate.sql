-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 29, 2019 at 11:29 AM
-- Server version: 5.1.37
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `movierate`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE IF NOT EXISTS `booking` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `Username` varchar(20) NOT NULL,
  `theatre` varchar(20) NOT NULL,
  `time` varchar(20) NOT NULL,
  `movie` varchar(30) NOT NULL,
  `date` varchar(20) NOT NULL,
  `seats` varchar(20) NOT NULL,
  `price` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`id`, `Username`, `theatre`, `time`, `movie`, `date`, `seats`, `price`) VALUES
(1, 'shino007', 'Kairali', '10:00 pm', 'Lucifer', '2019-05-07', '5-8', 100),
(4, 'Pinku007', 'Archana', '10:00 pm', 'Lucifer', '2019-06-01', '6-8', 100),
(3, 'shino007', 'Varsha', '11:00 am', 'Virus', '2019-05-07', '5-9', 100),
(5, 'shino007', 'Kairali', '6:30 pm', 'Lucifer', '2019-05-07', '4-7 4-8 5-8', 300),
(28, 'shino889', 'Archana', '10:00 pm', 'Lucifer', '2019-05-22', '5-9 5-10 6-10', 300),
(23, 'shino007', 'Dhanya', '6:30 pm', 'Endgame', '2019-05-22', 'A2 A3', 200),
(29, 'shino007', 'Archana', '10:00 pm', 'Lucifer', '2019-05-21', '6-3 5-4 5-5 5-6', 400);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `Username` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Type` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`Username`, `Password`, `Type`) VALUES
('shino007', '12345', 'USER'),
('Admin', 'admin', 'ADM'),
('Pinku007', '12345', 'USER'),
('rahul123', 'rahul123', 'USER'),
('akhilrko', 'akhilrko', 'USER'),
('shino889', '12345', 'USER');

-- --------------------------------------------------------

--
-- Table structure for table `movie`
--

CREATE TABLE IF NOT EXISTS `movie` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `theatre` varchar(20) NOT NULL,
  `movie` varchar(20) NOT NULL,
  `time` varchar(20) NOT NULL,
  `location` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `movie`
--

INSERT INTO `movie` (`id`, `theatre`, `movie`, `time`, `location`) VALUES
(1, 'Kairali', 'Lucifer', '10:00 pm', 'Kollam'),
(5, 'Ramraj', 'Endgame', '11:00 am', 'Alapuzha'),
(4, 'Archana', 'Lucifer', '10:00 pm', 'Kollam'),
(6, 'Ramraj', 'Lucifer', '6:30 pm', 'Alapuzha'),
(7, 'Vismaya', 'Madhuraraja', '6:30 pm', 'Alapuzha'),
(8, 'Nila', 'Madhuraraja', '10:00 pm', 'Kollam'),
(9, 'Dhanya', 'Endgame', '6:30 pm', 'TVM'),
(10, 'Carnival', 'Lucifer', '6:30 pm', 'TVM'),
(11, 'Kairali', 'Virus', '6:30 pm', 'TVM');

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE IF NOT EXISTS `rating` (
  `User_id` varchar(20) NOT NULL,
  `movie` varchar(30) NOT NULL,
  `rate` float NOT NULL,
  `comments` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rating`
--

INSERT INTO `rating` (`User_id`, `movie`, `rate`, `comments`) VALUES
('Pinku007', 'Lucifer', 3, 'Nice Movie with Great hardworks'),
('shino007', 'Madhuraraja', 3.5, 'Good Movie'),
('akhilrko', 'Lucifer', 5, 'Excellent Movie'),
('shino889', 'Lucifer', 2, 'Bad Movie'),
('shino007', 'Endgame', 5, 'Good Movie, Excellent WOrk, Nice job'),
('Pinku007', 'Endgame', 4.5, 'Excellent Movie'),
('Pinku007', 'Madhuraraja', 2.5, 'Average Movie'),
('shino007', 'Lucifer', 4.5, 'Good Movie');

-- --------------------------------------------------------

--
-- Table structure for table `theatre`
--

CREATE TABLE IF NOT EXISTS `theatre` (
  `t_id` int(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `location` varchar(20) NOT NULL,
  `contact` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `theatre`
--

INSERT INTO `theatre` (`t_id`, `name`, `location`, `contact`) VALUES
(101, 'Kairali', 'TVM', '2147483647'),
(102, 'Nila', 'TVM', '9745620564'),
(103, 'Archana', 'Kollam', '9878987657'),
(104, 'Varsha', 'Kollam', '8978657898'),
(105, 'Ramraj', 'Alapuzha', '8745678345'),
(112, 'David', 'TVM', '9745620564'),
(123, 'David', 'Alappuzha', '6786756546'),
(102, 'Pranav', 'Thodupuzha', '4567898987');

-- --------------------------------------------------------

--
-- Table structure for table `u_reg`
--

CREATE TABLE IF NOT EXISTS `u_reg` (
  `User_id` int(10) NOT NULL AUTO_INCREMENT,
  `Username` varchar(20) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Phone` varchar(10) NOT NULL,
  `Password` varchar(10) NOT NULL,
  PRIMARY KEY (`User_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `u_reg`
--

INSERT INTO `u_reg` (`User_id`, `Username`, `Name`, `Email`, `Phone`, `Password`) VALUES
(1, 'shino007', 'Shino K Shaji', 'sks@gmail.com', '9745620564', '12345'),
(2, 'Pinku007', 'Pranav A S', 'pinku@gmail.com', '8978654789', '12345'),
(3, 'rahul123', 'Rahul Raj', 'rahul@gmail.com', '7889657484', 'rahul123'),
(4, 'akhilrko', 'Akhil S S', 'akhil@gmail.com', '8978965789', 'akhilrko'),
(5, 'shino889', 'Shino K Shaji', 'shino@gmail.com', '8976898767', '12345');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
